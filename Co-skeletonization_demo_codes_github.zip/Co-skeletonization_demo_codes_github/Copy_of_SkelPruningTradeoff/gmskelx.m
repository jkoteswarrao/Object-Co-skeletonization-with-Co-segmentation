function [ mmc ] = gmskel(slf)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

alpha = 9.0;
threshold = 0.001;
slf=double(slf);
bw1=im2bw(slf,graythresh(slf));

% 
BW = imfill(bw1, 'holes');
bw1=BW*0;
 CC = bwconncomp(BW);
        numPixels = cellfun(@numel,CC.PixelIdxList);
        [biggest,idx] = max(numPixels);
        bw1(CC.PixelIdxList{idx}) = 1;


[m,n] = size(bw1);

% se = strel('disk',2);
% bw1 = imdilate(bw1,se);
% bw1 = imclose(bw1,se);


%figure,imshow(bw1)


%skeleton pruning

[skel_image, skel_dist, I0, endpoint, branches, tendpoint,weights,ars,slrs,epl] = DSE(bw1,50, alpha,threshold);


%save the skeleton
skel_image = skel_image/2;

%[sx,sy] = find(skel_image == 0);
%list = [sx,sy];

mm=skel_image*0;
mm(skel_image == 0)=1;
mm=im2bw(mm);

mmc=mm(4:end-3,4:end-3);

end

