function [] = constsal(dirname)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

mpath='./';
workImageDir=dirname;
files=dir(dirname);
for i=1:size(files)
    [p,fl,e]=fileparts(files(i).name);
    
    if strcmp(e,'.bmp')
        I=imread(files(i).name);
        imwrite(I,strcat(dirname,fl,'.jpg'));
    end
    
end
outDir=strcat(dirname,'\constsalf');


cmd = [fullfile(mpath,'ContrastSaliency/Release/ImgSaliency.exe') ' "' fullfile(workImageDir, '*.jpg') '" "' outDir '"'];

system(cmd);
end

