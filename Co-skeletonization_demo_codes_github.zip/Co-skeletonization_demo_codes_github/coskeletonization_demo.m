db='./camel/';
run('./vlf2\vlfeat-0.9.17\toolbox\vl_setup');
co_skeletonization(db);