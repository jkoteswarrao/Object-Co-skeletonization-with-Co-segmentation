mask=imread('horse.png');
addpath(genpath('./Copy_of_SkelPruningTradeoff/'));
skeleton=mask2skel(mask);
figure,imshow([mask,skeleton]);