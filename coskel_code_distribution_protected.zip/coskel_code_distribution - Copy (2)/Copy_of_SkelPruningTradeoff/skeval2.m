function [zx] = skeval2(cat)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

st1=strcat('C:\Users\Koteswar\Dropbox\skeletonproject\sk506\SK506\images\coskel\',cat,'\skelgt\');
st2=strcat('C:\Users\Koteswar\Dropbox\skeletonproject\sk506\SK506\images\coskel\',cat,'\mask\res2\');
fxx=0;
dr=dir([st2 '*.png']);
for i=1:numel(dr)
    dr(i).name
    gt=double(imread(strcat(st1,dr(i).name)));
    rs=double(imread(strcat(st2,dr(i).name)));
    rs=rs(:,:,1);
    [Mp,Np]=size(rs);
    rs=rs(4:Mp-3,4:Np-3);
     x=3;
            se = strel('disk',round(x));

     rs=imdilate(rs,se);
     
     %gt=imdilate(gt,se);
    m2=gt+rs;
    unique(m2)
    list1=find(m2==2);
    
    list2=find(rs==1);
        
    list3=find(gt==1);
    list4=find(m2==0);
   % imwrite(rs,strcat(st2,'/dil/',dr(i).name));
    pre=numel(list1)/numel(list2);
    rec=numel(list1)/numel(list3);
    fx=2*pre*rec/(pre+rec);
    fxx=fxx+fx;
    fxx/i
    
end

zx=fxx/i;

end
