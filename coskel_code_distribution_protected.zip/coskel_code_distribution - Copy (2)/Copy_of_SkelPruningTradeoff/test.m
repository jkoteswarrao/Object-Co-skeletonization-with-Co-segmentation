
alpha = 9.0;
threshold = 0.001;
dir = './'
sf = strcat(dir, '13.png');



I = imread(sf);
se = strel('disk',5);
I = imclose(I,se);

I = I .* 255;
bw1=im2bw(I);

bw1(:,30:80)=0;

bw1 = imfill(bw1, 'holes');
[m,n] = size(bw1);



imwrite(bw1,'./14.png')
%skeleton pruning
tic;
[skel_image, skel_dist, I0, endpoint, branches, tendpoint,weights,ars,slrs,epl] = DSE2(bw1,50, alpha,threshold,bw1);
toc;

figure,imshow(skel_image)
%save the skeleton
skel_image = skel_image/2;

[sx,sy] = find(skel_image == 0);
list = [sx,sy];
mm=skel_image*0;
mm(skel_image == 0)=1;
mm=im2bw(mm);
figure,imshow(mm);
skel_image = my_plot(skel_image, list, [0 0 0], 1);

bw1 = strcat(sf ,'-wskeleton.jpg');
imwrite(skel_image,bw1);




bw2 = strcat(sf ,'-orskeleton.jpg');
imwrite(skel_dist + I0,bw2);