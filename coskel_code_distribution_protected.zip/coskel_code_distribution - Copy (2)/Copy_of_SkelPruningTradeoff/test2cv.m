
alpha = 9.0;
threshold = 0.001;
strx='F:\skpro\CosegRep\';

drt=dir(strcat(strx,'\skpl\'));

for t=9:9%numel(drt)



str=strcat(strx,'\skpl\',drt(t).name,'\');
str2=strcat(strx,drt(t).name,'\GroundTruth\');
dr=dir([str '*.jpg']);
mkdir(strcat(str,'/res1j/'))
mkdir(strcat(str,'/res2j/'))
for i=1:numel(dr)
sf = strcat(str,dr(i).name);

[~,fl,~]=fileparts(dr(i).name);
sf2= strcat(str2,fl,'.jpg');
I = double(im2bw(mat2gray(imread(sf2)),0.5));

% se = strel('disk',3);
% I = imdilate(I,se);
% I = imclose(I,se);

I = I .* 255;
bw1=im2bw(I);
unique(bw1(:))
% 
BW = imfill(bw1, 'holes');
bw1=BW*0;
 CC = bwconncomp(BW);
        numPixels = cellfun(@numel,CC.PixelIdxList);
        [biggest,idx] = max(numPixels);
        bw1(CC.PixelIdxList{idx}) = 1;


[m,n] = size(bw1);

%figure,imshow(bw1)


%skeleton pruning
tic;
[skel_image, skel_dist, I0, endpoint, branches, tendpoint,weights,ars,slrs,epl] = DSE(bw1,50, alpha,threshold);
toc;

%save the skeleton
skel_image = skel_image/2;

[sx,sy] = find(skel_image == 0);
list = [sx,sy];

mm=skel_image*0;
mm(skel_image == 0)=1;
mm=im2bw(mm);

skel_image = my_plot(skel_image, list, [0 0 0], 1);

bw1 = strcat(str,'/res1j/',fl,'-wskeleton.jpg');
imwrite(skel_image(4:end-3,4:end-3,:),bw1);




bw2 = strcat(str,'/res2j/',fl,'.png');
imwrite(mm(4:end-3,4:end-3,:),bw2);
end
end