db='............................\Object-Co-skeletonization-with-Co-segmentation-master\CO-SKEL_v1.1/CO-SKEL_v1.1/images/';% Give path for CO-SKEL datset 
%results obtained as sub folders in the given path
vlf

cd ./grabcut/Grabcut/
try
compile_gc
catch
end
cd ..
cd ..

max_itr=2;
flk=dir(db);
for k=3:numel(flk)
    db_ar{k-2}=flk(k).name;
end

 for i=1:numel(db_ar)

 str=strcat(db,db_ar{i},'\');
 coskeletonization(str,max_itr);

 end
 
