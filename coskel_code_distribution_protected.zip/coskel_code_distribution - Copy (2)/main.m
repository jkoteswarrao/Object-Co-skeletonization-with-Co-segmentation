function [] =main()

db='C:\Users\GEU\Downloads\CO-SKEL_v1d\CO-SKEL_v1\images\';
addpath(genpath('./mexDenseSIFT/'));
addpath(genpath('./grabcut/'));
addpath(genpath('./SiftFlow/'));
addpath(genpath('./data/'));
addpath(genpath('./Copy_of_SkelPruningTradeoff/'));
run('./vlf2\vlfeat-0.9.17\toolbox\vl_setup')

%db_ar={'test2/'};
flk=dir(db);
for k=3:numel(flk)
    db_ar{k-2}=flk(k).name;
end

%--saliency enhancement parameters---
mu=330;
sigma=25;

%--foreground threshold-- the tuning parameter--- 
tau=0.972;

mbK=10;% expected number of images in a cluster




 



 parfor i=1:numel(db_ar)
     for it=3:5
 str=strcat(db,db_ar{i},'\');
 GMS174(str,mu,tau,sigma,mbK,it);
     end
 end
 


end

