function [fxx,scx,jmx,sjmx,i] = sklvl(st1,st2,st3,st4)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
sjmx=0;
fxx=0;
scx=0;jmx=0;tresx=0;
dr=dir([st2 '*.png']);
for i=1:numel(dr)
    dr(i).name
    [~,fl,~]=fileparts(dr(i).name);
    fl
if exist(strcat(st1,fl,'.jpg'),'file')||exist(strcat(st1,fl,'.png'),'file')
        'hey'
    [~,fl,~]=fileparts(dr(i).name);
    try
    gt=double(imread(strcat(st1,fl,'.png')));
    catch
           gt=double(imread(strcat(st1,fl,'.jpg')));
    end
    
    rs=double(imread(strcat(st2,dr(i).name)));
    try
sgt=double(imread(strcat(st3,fl,'.png')));
    catch
   sgt=double(imread(strcat(st3,fl,'.jpg')));     
    end
srs=double(imread(strcat(st4,dr(i).name)));
   rs=double(im2bw(mat2gray(rs),graythresh(mat2gray(rs))));
   sgt=double(im2bw(mat2gray(sgt),graythresh(mat2gray(sgt))));
   srs=double(im2bw(mat2gray(srs),graythresh(mat2gray(srs))));
    Mp=size(rs,1);Np=size(rs,2);
        gt=double(im2bw(mat2gray(imresize(gt,[Mp,Np],'nearest')),0.5));
        
    tresm=3;%round(Mp/100);
    
    
    mask2=[0 1 1 1 0
           1 1 1 1 1
           1 1 1 1 1
           1 1 1 1 1
           0 1 1 1 0];
    mask3=[0 0 1 1 1 0 0
           0 1 1 1 1 1 0
           1 1 1 1 1 1 1
           1 1 1 1 1 1 1
           1 1 1 1 1 1 1
           0 1 1 1 1 1 0
           0 0 1 1 1 0 0];
    
    
    
    %tresx=tresx+tres;
%     rs=rs(4:Mp-3,4:Np-3);
%      x=3;
%             se = strel('disk',round(x));
 
%      rs=imdilate(rs,se);
%      
%      gt=imdilate(gt,se);
% figure,imshow(sgt)
% figure,imshow(srs)
    m2=gt+rs;
    unique(m2)
    
    sjm=j_measure(sgt,srs);
    list1=find(m2==2);
    listr=find(m2==1);
     jm=numel(list1)/(numel(list1)+numel(listr)+eps);
    scr=0;
    [M,N]=find(gt==1);
    for k=1:numel(M)
        if tresm==1||M(k)-tresm<1||M(k)+tresm>Mp||N(k)-tresm<1||N(k)+tresm>Np
       trf=sum(sum(rs(max(1,M(k)-tresm):min(M(k)+tresm,Mp),max(1,N(k)-tresm):min(Np,N(k)+tresm))));
        elseif tresm==2
       trf=sum(sum(rs(max(1,M(k)-tresm):min(M(k)+tresm,Mp),max(1,N(k)-tresm):min(Np,N(k)+tresm)).*mask2));
        else
           
       trf=sum(sum(rs(max(1,M(k)-tresm):min(M(k)+tresm,Mp),max(1,N(k)-tresm):min(Np,N(k)+tresm)).*mask3));
        end

         if trf>0
            scr=scr+1;
        end
    end
    
    scr=scr/(numel(M)+eps);
    
    scr2=0;
    [M2,N2]=find(rs==1);
    for k=1:numel(M2)
        if tresm==1||M2(k)-tresm<1||M2(k)+tresm>Mp||N2(k)-tresm<1||N2(k)+tresm>Np
       trf=sum(sum(gt(max(1,M2(k)-tresm):min(M2(k)+tresm,Mp),max(1,N2(k)-tresm):min(Np,N2(k)+tresm))));
        elseif tresm==2
       trf=sum(sum(gt(max(1,M2(k)-tresm):min(M2(k)+tresm,Mp),max(1,N2(k)-tresm):min(Np,N2(k)+tresm)).*mask2));
        else
            
       trf=sum(sum(gt(max(1,M2(k)-tresm):min(M2(k)+tresm,Mp),max(1,N2(k)-tresm):min(Np,N2(k)+tresm)).*mask3));
        end
         if trf>0
            scr2=scr2+1;
        end
    end
    
    scr2=scr2/(numel(M2)+eps);
    
    
    
   
    
    
    list2=find(rs==1);
        
    list3=find(gt==1);
    list4=find(m2==0);
   % figure,imshow([rs,gt]);
   % imwrite(rs,strcat(st2,'/dil/',dr(i).name));
    pre=numel(list1)/(numel(list2)+eps);
    rec=numel(list1)/(numel(list3)+eps);
    fx=2*pre*rec/(pre+rec+eps);
    fxx=fxx+fx;
    scx=scx+2*scr2*scr/(scr+scr2+eps);
    jmx=jmx+jm;
    sjmx=sjmx+sjm;
    
%     fxx/i
%     scx/i
    jmx/i
end
end
if i
fxx=fxx/i
  scx=scx/i
    jmx=jmx/i
    tresx=tresx/i
    sjmx=sjmx/i
else
    i=1;
    fxx=fxx/i
     scx=scx/i
    jmx=jmx/i
    tresx=tresx/i
    sjmx=sjmx/i
    i=0;
end
end

