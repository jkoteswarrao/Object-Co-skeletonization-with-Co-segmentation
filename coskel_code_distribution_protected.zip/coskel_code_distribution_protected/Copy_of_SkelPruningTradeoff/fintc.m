alpha = 9.0;
threshold = 0.001;

str='C:\Users\Koteswar\Dropbox\skeletonproject\sk506\SK506\images\coskel\bear\salf2\';
str2='C:\Users\Koteswar\Dropbox\skeletonproject\sk506\SK506\images\coskel\bear\imsm\';
dr=dir([str '*.png']);
mkdir(strcat(str,'/res1/'))
mkdir(strcat(str,'/res2/'))
for i=1:numel(dr)
sf = strcat(str,dr(i).name);

[~,fl,~]=fileparts(dr(i).name)
I = imread(sf);

se = strel('disk',3);
I = imdilate(I,se);
I = imclose(I,se);

I = I .* 255;
bw1=im2bw(I);


bw1 = imfill(bw1, 'holes');
[m,n] = size(bw1);




%skeleton pruning
tic;
try
[skel_image, skel_dist, I0, endpoint, branches, tendpoint,weights,ars,slrs,epl] = DSE(bw1,50, alpha,threshold);
catch
    continue;
end
toc;

%save the skeleton
skel_image = skel_image/2;

[sx,sy] = find(skel_image == 0);
list = [sx,sy];

mm=skel_image*0;
mm(skel_image == 0)=1;
mm=im2bw(mm);

skel_image = my_plot(skel_image, list, [0 0 0], 1);

bw1 = strcat(str,'/res1/',fl,'-wskeleton.jpg');
imwrite(skel_image,bw1);




bw2 = strcat(str,'/res2/',fl,'.png');
imwrite(mm,bw2);
end