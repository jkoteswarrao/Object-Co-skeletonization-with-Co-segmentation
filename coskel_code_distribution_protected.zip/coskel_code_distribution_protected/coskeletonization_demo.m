db='./camel/';


max_itr=2;
vlf;
coskeletonization(db,max_itr);