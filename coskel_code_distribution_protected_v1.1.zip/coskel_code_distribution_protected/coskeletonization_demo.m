db='./camel/';
%results obtained as sub folders in the given path

max_itr=2;
vlf;
coskeletonization(db,max_itr);