%dest='C:\Users\KOTESWAR\Dropbox\skl\skpro\CVPR2017\CO-SKEL\';
dest='C:\Users\KOTESWAR\Dropbox\skl\skpro\CVPR2017\WH-SYMMAX\imgs\';
%src='F:\freshdatasetsnew2\';
src='C:\Users\KOTESWAR\Dropbox\skl\skpro\CVPR2017\WH-SYMMAX\gt\';
alpha = 9.0;
threshold = 0.001;
addpath(genpath(dest));
dr1=dir(dest);
for i=3:numel(dr1)
    dr2=dir(strcat(dest,dr1(i).name,'\'));
    for j=3:numel(dr2)
        mkdir(strcat(dest,dr1(i).name,'\',dr2(j).name,'\gtwsc2\'));
          mkdir(strcat(dest,dr1(i).name,'\',dr2(j).name,'\gtskc2\'));
          mkdir(strcat(dest,dr1(i).name,'\',dr2(j).name,'\gtsko\'));
        mkdir(strcat(dest,dr1(i).name,'\',dr2(j).name,'\GroundTruth\'));
        dr3=dir([strcat(dest,dr1(i).name,'\',dr2(j).name,'\') '*.jpg']);
        for k=1:numel(dr3)
            [~,fl,~]=fileparts(dr3(k).name);
          %  try
                ghj=load(strcat(src,dr1(i).name,'\',dr2(j).name,'\',fl,'.mat'));
                bw1=ghj.segmentation;
                old=logical(ghj.sym);
                
%             catch
%                 try
%                    gt= imread(strcat(src,dr1(i).name,'\',dr2(j).name,'\GroundTruth\',fl,'.bmp'));
%                 catch
%                     gt=imread(strcat(src,dr1(i).name,'\',dr2(j).name,'\GroundTruth\',fl,'.jpg'));
%                 end
%                 
%             end
%             if size(gt,3)==3
%                 gt=mean(gt,3);
%                 
%                 
%             end
%             gt=mat2gray(gt);
%             gt=im2bw(gt,graythresh(gt));
             imwrite(bw1,strcat(dest,dr1(i).name,'\',dr2(j).name,'\GroundTruth\',fl,'.png'))
%             'happening'
             imwrite(old,strcat(dest,dr1(i).name,'\',dr2(j).name,'\gtsko\',fl,'.png'))

           BW = imfill(bw1, 'holes');
bw1=BW*0;
 CC = bwconncomp(BW);
        numPixels = cellfun(@numel,CC.PixelIdxList);
        [biggest,idx] = max(numPixels);
        bw1(CC.PixelIdxList{idx}) = 1;


[m,n] = size(bw1);

%figure,imshow(bw1)


%skeleton pruning
tic;
[skel_image, skel_dist, I0, endpoint, branches, tendpoint,weights,ars,slrs,epl] = DSE(bw1,50, alpha,threshold);
toc;

%save the skeleton
skel_image = skel_image/2;

[sx,sy] = find(skel_image == 0);
list = [sx,sy];

mm=skel_image*0;
mm(skel_image == 0)=1;
mm=im2bw(mm);

skel_image = my_plot(skel_image, list, [0 0 0], 1);

bw1 = strcat(dest,dr1(i).name,'\',dr2(j).name,'/gtwsc/',fl,'-wskeleton.jpg');
imwrite(skel_image(4:end-3,4:end-3,:),bw1);


bw2 = strcat(dest,dr1(i).name,'\',dr2(j).name,'/gtskc/',fl,'.png');
imwrite(mm(4:end-3,4:end-3,:),bw2);


        end
    end
end