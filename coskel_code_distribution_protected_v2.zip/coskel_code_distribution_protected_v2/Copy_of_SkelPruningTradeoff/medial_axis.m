 
I=imread('14.png');
I = padarray(I, [3,3]);
            BW = imfill(I, 'holes');
            bw1=BW*0;
             CC = bwconncomp(BW);
                    
                    bw1(CC.PixelIdxList{idx}) = 1;
                    
                    ifg=1;
                        refsk2=bw1*0;
                    for kt=1:CC.NumObjects
                  
                        
                           
                            bwx=bw1*0;
                            bwx(CC.PixelIdxList{1,kt})=1;
                            bwx=1-bwx;
                            [refsk1,~,~,~,~,~,~,~]=div_skeleton_new(4,1,1,bwx,50);
                            
                            refsk2=refsk2+refsk1;
                        
                    end
                    figure,imshow(mat2gray(refsk2))