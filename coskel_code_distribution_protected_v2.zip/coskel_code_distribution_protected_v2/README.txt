
Following are the instructions for running the code: 
Run coskeletonization_demo.m for the demo of co-skeletonization.
Run skeletonization_demo.m for the the demo of mask to skeleton conversion. 
Run On_COSKEL_dataset.m for applying the method on entire CO-SKEL datset. (Change the path before running)
Run evaluate_coskeletonization_cosegmentation.m for evaluating skeletonization and segmentation. (Change the paths before running)


Settings:


max_itr for:
1) CO_SKEL datset, it's 2.
2) WHSYMMAX dataset, it's 5.
3) SK 506 dataset, it's 1.
