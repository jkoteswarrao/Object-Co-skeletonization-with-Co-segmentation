db='./camel/';


max_itr=2;
vlf;

cd ./grabcut/Grabcut/
try
compile_gc
catch
end
cd ..
cd ..
coskeletonization(db,max_itr);