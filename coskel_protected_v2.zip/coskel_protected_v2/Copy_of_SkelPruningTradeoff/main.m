function [] =main()

db='C:\Users\KOTESWAR\Dropbox\skeletonproject\sk506\SK506\images\coskel\';




 

 
flx=dir(db)

zxc=0;
 for i=8:8%numel(flx)
 %str=strcat(db,flx(i).name)
 %str2=strcat(db,flx(i).name
 %testf(str);
 zxt=skeval2(flx(i).name);
 zxt
 end
 


end

