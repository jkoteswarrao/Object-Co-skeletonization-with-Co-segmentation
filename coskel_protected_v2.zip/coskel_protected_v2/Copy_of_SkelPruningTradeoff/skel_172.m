function [ mmc,rm] = skel_17(sp,slf)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
slf=double(slf);
alpha = 9.0;
threshold = 0.001;

bw1=im2bw(slf,graythresh(slf));
unique(bw1(:))
% 
BW = imfill(bw1, 'holes');
bw1=BW*0;
 CC = bwconncomp(BW);
        numPixels = cellfun(@numel,CC.PixelIdxList);
        [biggest,idx] = max(numPixels);
        


[m,n] = size(bw1);

% se = strel('disk',2);
% bw1 = imdilate(bw1,se);
% bw1 = imclose(bw1,se);
 it=1;
for k=1:CC.NumObjects
    numel(CC.PixelIdxList{1,k})
    numel(CC.PixelIdxList{1,idx})
    if numel(CC.PixelIdxList{1,k})>0.1*numel(CC.PixelIdxList{1,idx})
       if it==1
           it=0;
           bwl=padarray(bw1*0,[3 3]);
           rml=bwl*0;
       end
       bwx=bw1*0;
        bwx(CC.PixelIdxList{1,k})=1;
        [skel_image, skel_dist, I0, endpoint, branches, tendpoint,weights,ars,slrs,epl,rm] = DSE2(bwx,50, alpha,threshold,sp);
        bwl(skel_image == 0)=1;
        rml=rml+rm;
    end
end




mm=im2bw(bwl);

mmc=mm(4:end-3,4:end-3);

rm=rml(4:end-3,4:end-3);

end

