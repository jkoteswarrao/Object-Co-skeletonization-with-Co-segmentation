st1='F:\skpro\MSRC\skpl2\camel\res2j\';
st2='F:\skpro\MSRC\skpl2\camel\skeleton\';
fxx=0;
scx=0;jmx=0;
dr=dir([st2 '*.png']);
for i=1:numel(dr)
    dr(i).name
    gt=double(imread(strcat(st1,dr(i).name)));
    rs=double(imread(strcat(st2,dr(i).name)));
   rs=im2double(im2bw(rs,graythresh(rs)));
    [Mp,Np]=size(rs);
    tres=round((Mp+Np)/100);
%     rs=rs(4:Mp-3,4:Np-3);
%      x=3;
%             se = strel('disk',round(x));
 
%      rs=imdilate(rs,se);
%      
%      gt=imdilate(gt,se);
    m2=gt+rs;
    
    list1=find(m2==2);
    scr=0;
    [M,N]=find(gt==1);
    for k=1:numel(M)
        trf=sum(sum(rs(M-tres:M+tres,N-tres:N+tres)));
        if trf>0
            scr=scr+1;
        end
    end
    
    scr=scr/numel(M);
    
    
    
    jm=j_measure(gt,rs);
    
    
    list2=find(rs==1);
        
    list3=find(gt==1);
    list4=find(m2==0);
   % figure,imshow([rs,gt]);
   % imwrite(rs,strcat(st2,'/dil/',dr(i).name));
    pre=numel(list1)/numel(list2);
    rec=numel(list1)/numel(list3);
    fx=2*pre*rec/(pre+rec+eps);
    fxx=fxx+fx;
    scx=scx+scr;
    jmx=jmx+jm;
    fxx/i
    scx/i
    jmx/i
end