db='./camel/';


max_itr=2;
vlf;
cd ./grabcut/Grabcut/
compile_gc
cd ..
cd ..
coskeletonization(db,max_itr);