
%%

% replace the path as mentioned below
st1='Groundtruth_skeleton_path';
st2='Skeleton_results_path';
st3='Groundtruth_segmentation_path';
st4='Segmentation_results_path';

%%

addpath(st1)
addpath(st2)
addpath(st3)
addpath(st4)

[F3,J]=evaluation(st1,st2,st3,st4);