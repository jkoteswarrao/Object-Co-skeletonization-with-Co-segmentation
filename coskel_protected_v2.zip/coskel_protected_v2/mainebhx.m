function [z] =mainebh()

db='C:\Users\GEU\Downloads\CO-SKEL_v1d\CO-SKEL_v1\images\';
db2='C:\Users\GEU\Downloads\CO-SKEL_v1d\CO-SKEL_v1\GT_skeletons\';
db3='C:\Users\GEU\Downloads\CO-SKEL_v1d\CO-SKEL_v1\GT_masks\';
% 
 drt=dir(db);
for i=3:numel(drt)
    db_ar{i-2}=drt(i).name;
end



% %  db_ar={'cormorant2/'};
% 
% %--saliency enhancement parameters---
% 

%db_ar={'bear\'};





for i=1:numel(db_ar)
     if 1
 str=strcat(db,db_ar{i},'\');
str2=strcat(db2,db_ar{i},'\');
str3=strcat(db3,db_ar{i},'\');
%   sklvlres2(strcat(str,'/gtskc2/'),strcat(str,'/gtsko/'),strcat(str,'/GroundTruth/'),strcat(str,'/17m35/'),strcat(str,'/constsalf/'),strcat(str,'/lind/'),str,db_ar{i});
% [z(i,1),z(i,2),z(i,3),z(i,4),z(i,5)]=sklvlsd(str2,strcat(str,'/skeleton_masks/'),str3,strcat(str,'/segmentation_masks/'));
[z(i,1),z(i,2),z(i,3),z(i,4),z(i,5)]=sklvlsd(str2,strcat(str,'/17s32/'),str3,strcat(str,'/17m32/'));
     end

end

end

