function output = path_reconstruct(bw,path)

[leng,wid]=size(bw);
bw2=round(bw/sqrt(2));
output=zeros(leng,wid);

for u=1:size(path,1)
    x=path(u,1);y=path(u,2);
    radius=bw(x,y);rad2=bw2(x,y);
    output(max(1,x-rad2):min(leng,x+rad2),max(1,y-rad2):min(wid,y+rad2))=1;
    for k=max(1,x-radius):min(leng,x+radius)        
        if k>=x-rad2 && k<=x+rad2
            for j=max(1,y-radius):max(1,y-rad2-1)
                if sqrt((k-x)^2+(j-y)^2)<=radius && ~output(k,j)
                    output(k,j)=1;
                end
            end            
            for j=min(wid,y+rad2+1):min(wid,y+radius)
                if sqrt((k-x)^2+(j-y)^2)<=radius && ~output(k,j)
                    output(k,j)=1;
                end
            end            
        else
            for j=max(1,y-radius):min(wid,y+radius)
                if sqrt((k-x)^2+(j-y)^2)<=radius && ~output(k,j)
                    output(k,j)=1;
                end
            end
        end
    end
end
end

