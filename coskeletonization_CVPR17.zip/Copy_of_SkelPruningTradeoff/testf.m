function [] = testf(str)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
alpha = 9.0;
threshold = 0.001;


dr=dir([strcat(str,'/cosal/') '*.png']);
mkdir(strcat(str,'/res1/'));
mkdir(strcat(str,'/res2/'));

for i=1:numel(dr)


[~,fl,~]=fileparts(dr(i).name);
salf2=mat2gray(im2double(imread(strcat(str,'/cosal/',fl,'.png'))));
im=imread(strcat(str,'/smim/',fl,'.png'));
      %salf2=mat2gray(exp(5*salf2));
   [~,lb,~,~] = vl_quickseg(im,0.5,1,25);
            ulb=unique(lb)
            salfx=salf2;%mat2gray(exp(10*salf2));
            salft=salfx;
            for b=1:numel(ulb)
                lbs=find(lb==ulb(b));
                salft(lbs)=mean(salfx(lbs));
            end
        
            salf2=salft;

 otsu=graythresh(salf2);%)kmnsbw(255*salf2)/255;
         figure,imshow(salf2)
            [~,mm]=Grab_Cut(uint8(im),salf2,otsu,1-otsu);




I = mm;

se = strel('disk',5);
I = imdilate(I,se);
I = imclose(I,se);

I = I .* 255;
bw1=im2bw(I);


bw1 = imfill(bw1, 'holes');
[m,n] = size(bw1);




%skeleton pruning
tic;
try
[skel_image, skel_dist, I0, endpoint, branches, tendpoint,weights,ars,slrs,epl] = DSE(bw1,50, alpha,threshold);
catch
continue;
end
toc;

%save the skeleton
skel_image = skel_image/2;

[sx,sy] = find(skel_image == 0);
list = [sx,sy];

mm=skel_image*0;
mm(skel_image == 0)=1;
mm=im2bw(mm);

skel_image = my_plot(skel_image, list, [0 0 0], 1);

bw1 = strcat(str,'/res1/',fl,'-wskeleton.jpg');
imwrite(skel_image,bw1);




bw2 = strcat(str,'/res2/',fl,'.png');
imwrite(mm,bw2);
end

end

