db='./CO-SKEL_v1.1/images/';% Give path for CO-SKEL datset
%results obtained as sub folders in the given path
max_itr=2;
addpath(genpath('./RBD/'));
flk=dir(db);
clear db_ar;
for k=3:numel(flk)
    db_ar{k-2}=flk(k).name;
end
try
    for i=1:numel(db_ar)
        
        str=strcat(db,db_ar{i},'\');
        coskeletonization(str,max_itr);
        
    end
catch
    try
        compile;
        for i=1:numel(db_ar)
            
            str=strcat(db,db_ar{i},'\');
            coskeletonization(str,max_itr);
            
        end
    catch
        run('./vlf2\vlfeat-0.9.17\toolbox\vl_setup')
        for i=1:numel(db_ar)
            
            str=strcat(db,db_ar{i},'\');
            coskeletonization(str,max_itr);
            
        end
    end
    
end
