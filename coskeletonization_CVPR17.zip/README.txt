
Following are the instructions for running the code:

Run compile.m [NOTE: Pls comment line 5 of project.h in mexDenseSIFT and SiftFlow folders if you are compiling using visual studio in windows, and uncomment if you are in linux or mac os.] 
Run coskeletonization_demo.m for the demo of co-skeletonization.
Run skeletonization_demo.m for the the demo of mask to skeleton conversion. 
Run On_COSKEL_dataset.m for applying the method on entire CO-SKEL datset. (Check the path before running and modify if required)
Run evaluate_coskeletonization_cosegmentation.m for evaluating skeletonization and segmentation. (Change the paths before running). See evaluate_co_skel for example.


Settings:

max_itr for:
1) CO_SKEL datset, it's 2.
2) WHSYMMAX dataset, it's 5.
3) SK 506 dataset, it's 1.

If you find the code useful, kindly cite the following papers:

[1] K. R. Jerripothula, J. Cai, J. Lu and J. Yuan, "Object Co-skeletonization with Co-segmentation", IEEE Conference on Computer Vision and Pattern Recognition (CVPR), Honolulu, USA, 2017, pp. 6205-6213.

[2] K. R. Jerripothula, J. Cai, and J. Yuan, �CATS: Co-saliency Activated Tracklet Selection for Video Co-localization" 2016 European Conference on Computer Vision (ECCV), Springer International Publishing, Amsterdam,The Netherlands, 2016, Part VII, pp. 187-202.

[3] K. R. Jerripothula, J. Cai, F. Meng and J. Yuan, "Automatic image co-segmentation using geometric mean saliency" 2014 IEEE International Conference on Image Processing (ICIP), Paris, 2014, pp. 3277-3281.